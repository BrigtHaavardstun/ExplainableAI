# LaTeX template for masteroppgaver ved Institutt for informatikk ved UiB

Denne LaTeX templaten er basert på Diddern sin [UiB-LaTeX-Template](https://github.com/Diddern/UiB-LaTeX-Template) (se fork).

## Komme i gang

Clone og kompiler med din favoritt [TeX-distribusjon](https://www.latex-project.org/get/).

## Logo

Logo for ditt fakultet?
[UiB profilmanual](http://kapd.h.uib.no/profilmanual/99LastNed/99a_lastned.html)  
Endre til `canvas.png` hvis du ønsker kun logo uten fakultet.

## Lisens

UiB logo: Copyright (C) tilhørende Universitetet i Bergen.  
University Assignment Title Page: CC BY-NC-SA 3.0 WikiBooks
